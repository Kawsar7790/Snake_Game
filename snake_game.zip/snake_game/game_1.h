#ifndef GAMMIX_H_INCLUDED
#define GAMMIX_H_INCLUDED

#define  UP 1
#define DOWN -1
#define RIGHT 2
#define LEFT -2


#define MAX 60

void initGrid (int , int);
void drawGrid();
void drawShaap();
void drawkhabar();
void ultapalta(int & , int &);


#endif // GAMMIX_H_INCLUDED
